import axios from 'axios'

const CompRegistro = () =>{

    return(
        <h1>Vista Registro</h1>
    )
}

export default CompRegistro